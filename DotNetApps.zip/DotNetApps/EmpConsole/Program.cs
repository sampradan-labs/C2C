﻿// See https://aka.ms/new-console-template for more information

using EmpLib;


Person Rohit = new Person();
Rohit.Name = "Rohit";
Console.WriteLine(Rohit.Eat());

Person Lekha = new Person();
Lekha.Name = "Lekha";
Console.WriteLine(Lekha.Work());

//Base = new Derived() //REMOVE EMPID IN BELOW LINE
Person Rushabh = new Employee() { Designation="Intern", DOJ=DateTime.Now.AddMonths(-1)};
Rushabh.Name = "Rushabh";
((Employee)Rushabh).Designation = "Analyst";
Console.WriteLine(Rushabh.Work());
Console.WriteLine($"EmpId  for  {Rushabh.Name} is {((Employee)Rushabh).EmpId}");

Console.WriteLine(((Employee)Rushabh).AttendTraining("C2C"));

// Polyphorphism
Father SharmajisFather = new Father();
Console.WriteLine($"Sharmaji's Father: {SharmajisFather.Settle()}");
Console.WriteLine($"Sharmaji's father gets married: {SharmajisFather.GetMarried()}");
Console.WriteLine($"Sharmaji's father's concept of Drawing (Using Abstract): {SharmajisFather.Drawing()}");
Console.WriteLine($"Sharmaji's father's concept of Dating (Using Abstract): {SharmajisFather.WhatIsDating()}");

//using virtual, modifications are allowed using override. Overridden behaviour is executed as below
Father Sharmaji = new Child();
Console.WriteLine($"Sharmaji: {Sharmaji.Settle()}");
Console.WriteLine($"Sharmaji gets married: {Sharmaji.GetMarried()}");
Console.WriteLine($"Sharmaji's concept of Drawing (Using Abstract): {Sharmaji.Drawing()}");
Console.WriteLine($"Sharmaji's concept of Dating (Using Abstract): {Sharmaji.WhatIsDating()}");

//No virtual, modification disallowed by base class, forced modify using "new" keyword. Forced execution of derived class using
//typecasting ((Child)SharmajiV2).GetMarried()
Father SharmajiV2 = new Child();
Console.WriteLine($"Sharmaji V2 gets married: {((Child)SharmajiV2).GetMarried()}");

//See Overloading- Compile-time polymorphism below
Employee Vidyasagar = new Employee();
Vidyasagar.Name = "VidyaSagar";
Vidyasagar.Designation = "Security Systems Analyst";
Console.WriteLine(Vidyasagar.Work());
Console.WriteLine(Vidyasagar.Work("Solving bugs"));

//Exposing non-public information through public methods
Employee Srikar = new Employee();
Srikar.SetTaxInfo("I'm eligible in the 20% tax payer category");
Console.WriteLine(Srikar.GetTaxInfo());


//Test calling one constructor from another
Person Sricharan = new Person("AA2398FB2039AA1A", "+91 9818233484");
//This constructor should call the constructor that sets aadhar number
Console.WriteLine($"Aadhar : {Sricharan.Aadhar} | Mobile Number: {Sricharan.MobileNumber}");

Console.WriteLine($"Total Employee Count: {EmpUtils.EmpCount}");

//Adding employees to a temporary db - using static List<Employee>
EmpUtils.EmpDb.Add(Srikar);
EmpUtils.EmpDb.Add(Vidyasagar);
EmpUtils.EmpDb.Add(new Employee("AAEEI9382403903SS", "+91 982389799") { Name="Nidha", Designation="Analyst", Salary=600000});
EmpUtils.EmpDb.Add(new Employee("BBEEI9382403903SS", "+91 982389788") { Name = "Keerthi", Designation = "Analyst", Salary = 600000 });
EmpUtils.EmpDb.Add(new Employee("CCEEI9382403903SS", "+91 982389777") { Name = "Mahesh", Designation = "Sr Analyst", Salary = 900000 });
//Get all employees whose aadhar card starts with AA

var resultList = EmpUtils.EmpDb.Where((emp) => emp.Aadhar != null && emp.Aadhar.StartsWith("AA"));
resultList.ToList().ForEach((emp) => Console.WriteLine($"{emp.Name} | {emp.Aadhar} | {emp.Designation}"));

//Get all employees with salary greater that 6L


