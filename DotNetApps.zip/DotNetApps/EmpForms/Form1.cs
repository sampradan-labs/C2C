using EmpLib;

namespace EmpForms
{
    public partial class Form1 : Form
    {
        Employee KpmgEmp = new Employee();
        public Form1()
        {
            InitializeComponent();
            button1.Click += Button1_Click2;
            button1.Click += Button1_Click3;

            KpmgEmp.Join += Srikar_Join;
            KpmgEmp.Join += Rohit_Join;
            KpmgEmp.Join += Lekha_Join;
            KpmgEmp.Join += Keerthi_Join;
        }

        private void Keerthi_Join(object? sender, EventArgs e)
        {
            MessageBox.Show("Keerthi joined KPMG successfully!");
        }

        private void Lekha_Join(object? sender, EventArgs e)
        {
            MessageBox.Show("Lekha joined KPMG successfully!");
        }

        private void Rohit_Join(object? sender, EventArgs e)
        {
            MessageBox.Show("Rohit joined KPMG successfully!");
        }

        private void Srikar_Join(object? sender, EventArgs e)
        {
            MessageBox.Show("Srikar joined KPMG successfully!");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            KpmgEmp.TriggerJoinEvent();            
        }

        private void Button1_Click3(object? sender, EventArgs e)
        {
            MessageBox.Show("I am subscriber 3 of click event");
        }

        private void Button1_Click2(object? sender, EventArgs e)
        {
            MessageBox.Show("I am subscriber 2 of click event");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("I am subscriber 1 of click event");
        }

        
    }
}